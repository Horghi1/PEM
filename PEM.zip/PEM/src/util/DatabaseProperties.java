package util;

import java.io.FileInputStream;
import java.util.Properties;

public class DatabaseProperties {

    public static final String CONNECTION_URL = "jdbc:mysql://localhost:3306/pem_schema?serverTimezone=UTC";
    public static final String CONNECTION_USER = "root";
    public static final String CONNECTION_PASS = "@Faraparola10";

}


