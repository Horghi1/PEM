package model;

import java.sql.Date;

public class Income {

    private int id;
    private String type;
    private double amount;
    private int userId;
    private Date date;

    public Income(int id, String type, double amount, int userId, Date date) {
        this.id = id;
        this.type = type;
        this.amount = amount;
        this.userId = userId;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
